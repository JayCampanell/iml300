$(document).ready(function () {
  var colors = ["green", "blue", "red"];
  var counter = 0;
  $(".flower").click(function () {
    $("#paragraph").toggle();
    if (counter == colors.length) {
      counter = 0;
    }
    var current_color = colors[counter];
    console.log(current_color);
    counter++;
    $("body").css("background", current_color);
  });

  $("#imgage1").click(function () {
    $(this).toggleClass("bigger");
  });
  $(function () {
    $(".flower").draggable();
  });

  $(window).scroll(function () {
    // $("#hidden").toggleClass("show");

    $("body").css(
      "background",
      "linear-gradient(0deg, rgba(255,255,255,0) 50%, rgba(52,255,0,0.5) 100%)"
    );
  });
});
